﻿using MyGarage.BusinessObjects;
using MyGarage.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarage.Controller
{
    
    class UsuarioController
    {

        /// Variaveis de Instancia

        private UsuarioModel usuarioModel;


        /// Construtor


        public UsuarioController()
        {
            usuarioModel = new UsuarioModel();
        }


        /// Metodos 

        public List<Usuario> listaUsuariosController( )
        {
            return usuarioModel.listaUsuariosModel();
        }

        public List<Usuario> pesquisaUsuariosController(Usuario usuario)
        {
            return usuarioModel.pesquisaUsuariosModel(usuario);
        }

        public Boolean deleteUsuarioController(Usuario usuario)
        {
            return usuarioModel.deleteUsuarioModel(usuario);
        }

        public Boolean alteraUsuarioController(Usuario usuario)
        {
            return usuarioModel.alteraUsuarioModel(usuario);
        }
    }


}
