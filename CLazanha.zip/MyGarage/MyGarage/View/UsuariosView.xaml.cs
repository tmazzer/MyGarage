﻿using MyGarage.BusinessObjects;
using MyGarage.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyGarage.View
{
    /// <summary>
    /// Interaction logic for UsuariosView.xaml
    /// </summary>
    public partial class UsuariosView : Window
    {

        private Usuario usuario;

        private List<Usuario> usuarioList;

        private UsuarioController usuarioController;

        public UsuariosView()
        {
            InitializeComponent();

            usuarioController = new UsuarioController();

            usuarioList = usuarioController.listaUsuariosController();

            montaDataGrid();
        }
       

        private void btnPesquisar_Click(object sender, RoutedEventArgs e)
        {
            if (txtPesquisaNome.Text == "")
            {
                usuarioList = usuarioController.listaUsuariosController();
                montaDataGrid();
                return;
            }

            usuario = new Usuario();

            usuario.Nome = txtPesquisaNome.Text;

            usuarioList = usuarioController.pesquisaUsuariosController(usuario);

            if (usuarioList == null)
            {
                MessageBox.Show("Nome não encontrado");
            }

            montaDataGrid();
            
        }

        private void dataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (this.dataGrid.SelectedItem == null)
            {
                return;
            }

            var selectedUsuario = this.dataGrid.SelectedItem as Usuario;

            this.usuario = selectedUsuario;

            txtIdUsuario.Text = usuario.IdUsuario.ToString();
            txtNome.Text = usuario.Nome;
            txtSobrenome.Text = usuario.Sobrenome;     
            txtTelefone.Text = usuario.Telefone;
            txtEmail.Text = usuario.Email;
            txtSenha.Text = usuario.Senha;
        }

        private void btnExcluir_Click(object sender, RoutedEventArgs e)
        {
            if (txtIdUsuario.Text == "")
            {
                MessageBox.Show("Selecionar Usuario na lista");
                return;
            }

            usuario.IdUsuario = int.Parse(txtIdUsuario.Text);

            if (usuarioController.deleteUsuarioController(usuario))
            {
                MessageBox.Show("Usuario excluido com sucesso!");
                limpaTela();
                usuarioList = usuarioController.listaUsuariosController();
                montaDataGrid();
            }
            else
            {
                MessageBox.Show("Erro ao excluir usuario!!");
            }
        }


        private void btnAlterar_Click(object sender, RoutedEventArgs e)
        {
            if (txtIdUsuario.Text == "")
            {
                MessageBox.Show("Selecionar Usuario na lista");
                return;
            }

            usuario.IdUsuario = int.Parse(txtIdUsuario.Text);
            usuario.Nome = txtNome.Text;
            usuario.Sobrenome = txtSobrenome.Text;
            usuario.Telefone = txtTelefone.Text;
            usuario.Email = txtEmail.Text;
            usuario.Senha = txtSenha.Text;

            if (usuarioController.alteraUsuarioController(usuario))
            {
                MessageBox.Show("Usuario alterado com sucesso!");
                limpaTela();
                usuarioList = usuarioController.listaUsuariosController();
                montaDataGrid();
            }
            else
            {
                MessageBox.Show("Erro ao alterar usuario!!");
            }
        }

        private void montaDataGrid()
        {
            dataGrid.ItemsSource = usuarioList;
        }

        private void limpaTela()
        {
            dataGrid.ItemsSource = null;
            txtIdUsuario.Text = "";
            txtNome.Text = "";
            txtSobrenome.Text = "";
            txtTelefone.Text = "";
            txtEmail.Text = "";
            txtSenha.Text = "";

        }

        /// <summary>
        /// FUNCOES DE MENU
        /// </summary>


        private void Usuarios_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            UsuariosView menu = new UsuariosView();
            menu.Show();
            this.Close();
        }

        private void Carros_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CarrosView menu = new CarrosView();
            menu.Show();
            this.Close();
        }

        private void Acessorios_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            AcessoriosView menu = new AcessoriosView();
            menu.Show();
            this.Close();
        }

        private void Eventos_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            EventosView menu = new EventosView();
            menu.Show();
            this.Close();
        }

        private void Grupos_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            GruposView menu = new GruposView();
            menu.Show();
            this.Close();
        }

        private void Logs_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            LogView menu = new LogView();
            menu.Show();
            this.Close();
        }

        private void btnSair_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
