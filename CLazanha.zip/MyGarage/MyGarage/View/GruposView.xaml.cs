﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyGarage.View
{
    /// <summary>
    /// Interaction logic for GruposView.xaml
    /// </summary>
    public partial class GruposView : Window
    {
        public GruposView()
        {
            InitializeComponent();
        }
        private void Usuarios_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            UsuariosView menu = new UsuariosView();
            menu.Show();
            this.Close();
        }

        private void Carros_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CarrosView menu = new CarrosView();
            menu.Show();
            this.Close();
        }

        private void Acessorios_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            AcessoriosView menu = new AcessoriosView();
            menu.Show();
            this.Close();
        }

        private void Eventos_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            EventosView menu = new EventosView();
            menu.Show();
            this.Close();
        }

        private void Grupos_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            GruposView menu = new GruposView();
            menu.Show();
            this.Close();
        }

        private void Logs_MenuItem_Click(object sender, RoutedEventArgs e)
        {
            LogView menu = new LogView();
            menu.Show();
            this.Close();
        }

        private void btnSair_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
