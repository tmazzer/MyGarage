﻿using MyGarage.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyGarage
{
    /// <summary>
    /// Interaction logic for Menu.xaml
    /// </summary>
    public partial class Menu : Window
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void btnUsuario_Click(object sender, RoutedEventArgs e)
        {
            UsuariosView menu = new UsuariosView();
            menu.Show();
            this.Close();
        }

        private void btnCarro_Click(object sender, RoutedEventArgs e)
        {
            CarrosView menu = new CarrosView();
            menu.Show();
            this.Close();
        }

        private void btnAcessorio_Click(object sender, RoutedEventArgs e)
        {
            AcessoriosView menu = new AcessoriosView();
            menu.Show();
            this.Close();
        }

        private void btnEvento_Click(object sender, RoutedEventArgs e)
        {
            EventosView menu = new EventosView();
            menu.Show();
            this.Close();
        }

        private void btnGrupo_Click(object sender, RoutedEventArgs e)
        {
            GruposView menu = new GruposView();
            menu.Show();
            this.Close();
        }

        private void btnLog_Click(object sender, RoutedEventArgs e)
        {
            LogView menu = new LogView();
            menu.Show();
            this.Close();
        }
        private void btnSair_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
