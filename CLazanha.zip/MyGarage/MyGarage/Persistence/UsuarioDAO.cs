﻿using MyGarage.BusinessObjects;
using MyGarage.Useful;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarage.Persistence
{

    class UsuarioDAO : IUsuario
    {
        /// Variaveis de Instancia
        private List<Usuario> usuarioList;

        private SqlConnection sqlConnection;

        private Usuario usuario;

        /// Construtor
        public UsuarioDAO()
        {
            this.sqlConnection = ConnectionFactory.GetSqlConnection();
        }

        /// Metodos 
        public List<Usuario> listaUsuarios()
        {

            // Data processing

            if (this.sqlConnection == null)
            {
                return null;
            }

            try
            {
                usuarioList = new List<Usuario>();

                usuario = new Usuario();

                SqlCommand sqlCommand = new SqlCommand();

                sqlCommand.Connection = this.sqlConnection;

                sqlCommand.CommandText = "Select * From USUARIO Order by NOME";

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                if (sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        usuario = new Usuario();

                        usuario.IdUsuario = sqlDataReader.GetInt32(0);
                        usuario.Nome = sqlDataReader.GetString(1);
                        usuario.Sobrenome = sqlDataReader.GetString(2);
                        usuario.Telefone = sqlDataReader.GetString(3);
                        usuario.Email = sqlDataReader.GetString(4);
                        usuario.Senha = sqlDataReader.GetString(5);

                        usuarioList.Add(usuario);
                    }
                }
                else
                {
                    usuarioList = null;
                }

                sqlDataReader.Close();

            }
            catch (SqlException e)
            {
                usuarioList = null;
                Console.WriteLine("Erro no SQL: " + e);
            }

            // Information output

            return usuarioList;
        }

        public List<Usuario> pesquisaUsuarios(Usuario usuario)
        {

            // Data processing

            if (this.sqlConnection == null)
            {
                return null;
            }

            try
            {
                usuarioList = new List<Usuario>();

                SqlCommand sqlCommand = new SqlCommand();

                sqlCommand.Connection = this.sqlConnection;

                sqlCommand.CommandText = "Select * From USUARIO Where NOME LIKE @nome Order by NOME";

                sqlCommand.Parameters.AddWithValue("@nome", usuario.Nome);

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                if (sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        usuario = new Usuario();

                        usuario.IdUsuario = sqlDataReader.GetInt32(0);
                        usuario.Nome = sqlDataReader.GetString(1);
                        usuario.Sobrenome = sqlDataReader.GetString(2);
                        usuario.Telefone = sqlDataReader.GetString(3);
                        usuario.Email = sqlDataReader.GetString(4);
                        usuario.Senha = sqlDataReader.GetString(5);

                        usuarioList.Add(usuario);
                    }
                }
                else
                {
                    usuarioList = null;
                }

                sqlDataReader.Close();

            }
            catch (SqlException e)
            {
                usuarioList = null;
                Console.WriteLine("Erro no SQL: " + e);
            }

            // Information output

            return usuarioList;
        }
        public Boolean alteraUsuario(Usuario usuario)
        {
            int count;

            if (this.sqlConnection == null)
            {
                return false;
            }

            try
            {
                SqlCommand sqlComando = new SqlCommand();

                sqlComando.Connection = this.sqlConnection;

                sqlComando.CommandText = "Update USUARIO Set NOME = @nome, SOBRENOME = @sobrenome, TELEFONE = @telefone, EMAIL = @email, SENHA = @senha Where IDUSUARIO = @idUsuario";

                sqlComando.Parameters.AddWithValue("@idUsuario", usuario.IdUsuario);
                sqlComando.Parameters.AddWithValue("@nome", usuario.Nome);
                sqlComando.Parameters.AddWithValue("@sobrenome", usuario.Sobrenome);
                sqlComando.Parameters.AddWithValue("@telefone", usuario.Telefone);
                sqlComando.Parameters.AddWithValue("@email", usuario.Email);
                sqlComando.Parameters.AddWithValue("@senha", usuario.Senha);

                count = sqlComando.ExecuteNonQuery();

                if (count.Equals(1))
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (SqlException e)
            {
                Console.WriteLine("Erro no SQL: " + e);
                return false;
            }
        }

        public Boolean deletaUsuario(Usuario usuario)
        {
            int count;

            if (this.sqlConnection == null)
            {
                return false;
            }

            try
            {
                SqlCommand sqlComando = new SqlCommand();

                sqlComando.Connection = this.sqlConnection;

                sqlComando.CommandText = "Delete From USUARIO Where IDUSUARIO = @idUsuario";

                sqlComando.Parameters.AddWithValue("@idUsuario", usuario.IdUsuario);

                count = sqlComando.ExecuteNonQuery();

                if (count.Equals(1))
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (SqlException e)
            {
                Console.WriteLine("Erro no SQL: " + e);
                return false;
            }
        }

    }
}
