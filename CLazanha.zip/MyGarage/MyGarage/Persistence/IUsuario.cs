﻿using MyGarage.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarage.Persistence
{
    interface IUsuario
    {
        List<Usuario> listaUsuarios();

        List<Usuario> pesquisaUsuarios(Usuario usuario);

        Boolean deletaUsuario(Usuario usuario);

        Boolean alteraUsuario(Usuario usuario);
    }
}
