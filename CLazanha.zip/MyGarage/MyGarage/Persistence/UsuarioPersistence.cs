﻿using MyGarage.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarage.Persistence
{
    class UsuarioPersistence : IUsuario
    {
        /// Variaveis de Instancia
        private UsuarioDAO usuarioDAO;

        /// Construtor
        public UsuarioPersistence()
        {
            usuarioDAO = new UsuarioDAO();
        }

        /// Metodos 
        public List<Usuario> listaUsuarios(){
            return usuarioDAO.listaUsuarios();
        }

        public List<Usuario> pesquisaUsuarios(Usuario usuario)
        {
            return usuarioDAO.pesquisaUsuarios(usuario);
        }

        public Boolean deletaUsuario(Usuario usuario){
            return usuarioDAO.deletaUsuario(usuario);
        }

        public Boolean alteraUsuario(Usuario usuario)
        {
            return usuarioDAO.alteraUsuario(usuario);
        }

    }
}
