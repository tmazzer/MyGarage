﻿using MyGarage.BusinessObjects;
using MyGarage.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarage.Model
{
    class UsuarioModel
    {
        /// Variaveis de Instancia

        private UsuarioPersistence usuarioPersistence;

        /// Construtor


        public UsuarioModel()
        {
            usuarioPersistence = new UsuarioPersistence();
        }

        /// Metodos 

        public List<Usuario> listaUsuariosModel()
        {
            return usuarioPersistence.listaUsuarios();
        }

        public List<Usuario> pesquisaUsuariosModel(Usuario usuario)
        {
            return usuarioPersistence.pesquisaUsuarios(usuario);
        }

        public Boolean deleteUsuarioModel(Usuario usuario)
        {
            return usuarioPersistence.deletaUsuario(usuario);
        }

        public Boolean alteraUsuarioModel(Usuario usuario)
        {
            return usuarioPersistence.alteraUsuario(usuario);
        }
    }
}
