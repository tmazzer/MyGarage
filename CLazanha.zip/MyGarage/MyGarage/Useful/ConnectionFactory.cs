﻿using System;
using System.Data.SqlClient;
using System.Windows;


namespace MyGarage.Useful
{
    public class ConnectionFactory
    {
        private const string TITLE = "MyGarage";

        private static SqlConnection sqlConnection;

        private static string msg;

        private ConnectionFactory()
        {
            openDB();
        }

        private void openDB()
        {
            sqlConnection = new SqlConnection();

            try
            {
                sqlConnection.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\DEV\VSProjects\MyGarage\MyGarage\Database\LocalDB.mdf;Integrated Security=True";
                
                sqlConnection.Open();

                msg = "Conexão com o Banco de Dados realizada com sucesso!";

            }
            catch (Exception e)
            {
                Console.WriteLine("Erro no DB: " + e);
                msg = "Não foi possível realizar a conexão com o Banco de dados.";
                msg += "\nVerifique o caminho do diretório do arquivo mdf.";
            }

            Console.WriteLine(msg, TITLE, MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public static String CloseDB()
        {
            msg = null;

            if (sqlConnection != null)
            {

                try
                {
                    sqlConnection.Close();

                    msg = "Conexão com o Banco de Dados fechada com sucesso!";

                    sqlConnection = null;

                }
                catch (Exception e)
                {
                    msg = "Erro ao fechar o Banco de Dados!\n" + e.Message;
                }
            }

            Console.WriteLine(msg, TITLE, MessageBoxButton.OK, MessageBoxImage.Information);

            return msg;

        }

        public static SqlConnection GetSqlConnection()
        {
            if (sqlConnection == null)
            {
                new ConnectionFactory();
            }

            return sqlConnection;
        }
    }
}
