﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarage.Useful
{
    class MessageProperties
    {
        public const bool FLAG = true;

        public const string INSERT_SUCCESS = "Inserção realizada com sucesso";

        public const string INSERT_UNSUCCESS = "Não foi possível realizar inserção.";

        public const string INSERT_ERROR = "Erro ao realizar inserção.";

        public const string QUERY_SUCCESS = "Consulta realizada com sucesso";

        public const string QUERY_UNSUCESS = "Não foi possível realizar consulta.";

        public const string QUERY_ERROR = "Erro ao realizar consulta.";

        public const string UPDATE_SUCCESS = "Atualização realizada com sucesso.";

        public const string UPDATE_UNSUCCESS = "Não foi possível realizar atualização.";

        public const string UPDATE_ERROR = "Erro ao realizar atualização.";

        public const string DELETE_SUCCESS = "Exclusão realizada com sucesso.";

        public const string DELETE_UNSUCCESS = "Não foi possível realizar exclusão.";

        public const string DELETE_ERROR = "Erro ao realizar exclusão.";

        public const string RECOVERY_DATA_SUCCESS = "Recuperação de dados realizada com sucesso.";

        public const string RECOVERY_DATA_UNSUCCESS = "Não foi possível realizar recuperação de dados.";

        public const string RECOVERY_DATA_ERROR = "Erro ao realizar recuperação de dados.";

        public const string SEARCH_SUCCESS = "Pesquisa realizada com sucesso.";

        public const string SEARCH_UNSUCCESS = "Não foi possível realizar pesquisa.";

        public const string SEARCH_ERROR = "Erro ao realizar pesquisa.";

        public const string SEARCH_NO_OCCURRENCE = "Nenhuma ocorrência para o nome: ";

    }
}
